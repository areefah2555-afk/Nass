let parts = JSON.parse(localStorage.getItem('parts')) || [
  {name:'กรองน้ำมันเครื่อง', price:180},
  {name:'น้ำมันเครื่อง', price:850},
  {name:'หัวเทียน', price:120},
  {name:'ผ้าเบรกหน้า', price:950},
  {name:'ล้างหัวฉีด', price:1200}
];
let bill = [];

function saveParts(){ localStorage.setItem('parts', JSON.stringify(parts)); }
function money(n){ return Number(n || 0).toLocaleString('th-TH'); }

function renderParts(){
  const keyword = document.getElementById('searchInput').value.trim().toLowerCase();
  const box = document.getElementById('partsList');
  const filtered = parts.filter(p => p.name.toLowerCase().includes(keyword));
  box.innerHTML = filtered.map((p,i)=>`
    <div class="item">
      <div><b>${p.name}</b><br><small>${money(p.price)} บาท</small></div>
      <button class="add-btn" onclick="addToBill(${parts.indexOf(p)})">ใส่บิล</button>
    </div>`).join('') || '<p>ไม่พบรายการ</p>';
}

function addPart(){
  const name = document.getElementById('partName').value.trim();
  const price = Number(document.getElementById('partPrice').value);
  if(!name || !price){ alert('กรอกชื่ออะไหล่และราคาให้ครบ'); return; }
  parts.push({name, price});
  saveParts();
  document.getElementById('partName').value='';
  document.getElementById('partPrice').value='';
  renderParts();
}

function addToBill(index){
  bill.push(parts[index]);
  renderBill();
}

function removeBillItem(index){
  bill.splice(index,1);
  renderBill();
}

function renderBill(){
  const box = document.getElementById('billItems');
  box.innerHTML = bill.map((p,i)=>`
    <div class="item">
      <div><b>${p.name}</b><br><small>${money(p.price)} บาท</small></div>
      <button class="add-btn" onclick="removeBillItem(${i})">ลบ</button>
    </div>`).join('');
  const labor = Number(document.getElementById('laborCost').value || 0);
  const total = bill.reduce((sum,p)=>sum+Number(p.price),0)+labor;
  document.getElementById('totalPrice').textContent = money(total);
}

function printBill(){
  renderBill();
  window.print();
}

document.getElementById('searchInput').addEventListener('input', renderParts);
document.getElementById('laborCost').addEventListener('input', renderBill);
renderParts();
renderBill();
